EA DLC Unlocker for Mac
made by anadius

CS RIN thread: https://cs.rin.ru/forum/viewtopic.php?p=2085788#p2085788

==========================
Installation instructions:
==========================
1. Download and extract the ZIP archive - use default extraction tool,
   extract by double clicking on the ZIP archive.
2. Right/Control click on "prepare DLC Unlockers" and select "Open".
3. If you get the "Apple can't check app for malicious software" error
   follow these instructions:
   https://support.apple.com/guide/mac-help/apple-cant-check-app-for-malicious-software-mchleab3a043/mac
   (System Settings > Privacy & Security > Security > Open > Open Anyway)
4. Download DLC files if needed - links are on my website and in CS RIN thread.
   (Special note for Sims players - YES, you need the DLC files. DLC Unlocker
   doesn't download anything.)

This should create a DLC Unlocker app for each supported game.

**Important note**: Unlike other DLC Unlockers you need to run
                    this one every time you want to play.

===================
Usage instructions:
===================
1. Run one of the DLC Unlockers.
2. Run the EA app (click OK on error about port 3216).
3. Run the game.

============================
Uninstallation instructions:
============================
Just delete the DLC Unlocker apps, that's it.

=====================
Updates and new DLCs:
=====================
EA app and game updates have no effect on this DLC Unlocker.
When we get a new DLC - check if it's added to the DLC Unlocker
and then redownload it.
If the new DLC is still not unlocked - it's probably not out yet.
If you're 100% sure the DLC is out but it doesn't work even after
redownloading the DLC Unlocker - you're probably missing the DLC files.
